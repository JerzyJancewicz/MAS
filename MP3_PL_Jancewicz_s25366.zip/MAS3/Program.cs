﻿using MAS3.Models.Truck;

namespace MAS3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            DeliveryTruck deliveryTruck = new DeliveryTruck();
        }
    }
}