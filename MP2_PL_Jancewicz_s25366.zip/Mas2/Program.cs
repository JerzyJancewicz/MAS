﻿using Mas2.Models;

namespace Mas2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Course course = new Course("Test1", "Desc1");

            Lesson lesson = new Lesson("History", 45, course);
            Teacher teacher = new Teacher("Marek", "Konieczny", "marek.k@email.com");

            Participation participation = new Participation(teacher,lesson,"present", DateTime.Now);

            Student student = new Student("Jankowksi", "Edward");
            Grade grade = new Grade("History", "dst", "Could be better", student);
            
            student.AddLesson(lesson);
            lesson.AddStudent(student);
        }
    }
}