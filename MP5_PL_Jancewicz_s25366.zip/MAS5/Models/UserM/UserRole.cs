﻿namespace MAS5.Models.UserM
{
    public enum UserRole
    {
        EMPLOYEE,
        CLIENT
    }
}
